https://github.com/jfeinstein10/SlidingMenu
