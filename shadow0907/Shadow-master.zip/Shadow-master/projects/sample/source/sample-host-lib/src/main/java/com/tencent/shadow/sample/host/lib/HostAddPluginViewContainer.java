package com.tencent.shadow.sample.host.lib;

import android.view.View;

public interface HostAddPluginViewContainer {
    void addView(View view);
}
