package com.tencent.shadow.sample.host.lib;

import java.util.HashMap;
import java.util.Map;

public class HostAddPluginViewContainerHolder {
    public final static Map<Integer, HostAddPluginViewContainer> instances = new HashMap<>();
}
