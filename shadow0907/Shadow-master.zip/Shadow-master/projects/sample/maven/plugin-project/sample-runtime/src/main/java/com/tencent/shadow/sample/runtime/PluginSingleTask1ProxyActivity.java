package com.tencent.shadow.sample.runtime;


import com.tencent.shadow.core.runtime.container.PluginContainerActivity;

public class PluginSingleTask1ProxyActivity extends PluginContainerActivity {
}
