package com.tencent.shadow.sample.runtime;


import com.tencent.shadow.core.runtime.container.PluginContainerActivity;

public class PluginDefaultProxyActivity extends PluginContainerActivity {
}
