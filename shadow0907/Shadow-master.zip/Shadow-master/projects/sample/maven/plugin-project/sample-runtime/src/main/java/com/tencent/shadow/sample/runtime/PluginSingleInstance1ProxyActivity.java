package com.tencent.shadow.sample.runtime;


import com.tencent.shadow.core.runtime.container.PluginContainerActivity;

public class PluginSingleInstance1ProxyActivity extends PluginContainerActivity {
}
