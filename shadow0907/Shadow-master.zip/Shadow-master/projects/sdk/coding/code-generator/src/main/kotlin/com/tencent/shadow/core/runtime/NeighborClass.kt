package com.tencent.shadow.core.runtime

/**
 * 为了兼容JDK 17和javassist
 * https://github.com/jboss-javassist/javassist/issues/369
 */
class NeighborClass