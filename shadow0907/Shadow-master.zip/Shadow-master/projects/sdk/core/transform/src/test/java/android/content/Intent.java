package android.content;

public class Intent {
    public Intent() {
    }

    public Intent(Intent intent) {
    }

    public void setExtrasClassLoader(ClassLoader loader) {
    }
}
