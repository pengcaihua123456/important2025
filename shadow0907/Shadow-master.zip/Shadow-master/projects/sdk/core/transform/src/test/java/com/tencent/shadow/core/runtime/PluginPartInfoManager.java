package com.tencent.shadow.core.runtime;

public class PluginPartInfoManager {
    public static PluginPartInfo getPluginInfo(ClassLoader classLoader) {
        return new PluginPartInfo();
    }
}
