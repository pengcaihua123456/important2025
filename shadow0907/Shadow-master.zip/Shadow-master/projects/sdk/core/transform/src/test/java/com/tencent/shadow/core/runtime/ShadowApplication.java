package com.tencent.shadow.core.runtime;

public class ShadowApplication extends ShadowContext {

    public void onCreate() {
    }
}
