package com.tencent.shadow.core.runtime;

public class ShadowActivity {
}
