package com.tencent.shadow.core.runtime;

import android.content.Context;

public class ShadowContext extends Context {
}
