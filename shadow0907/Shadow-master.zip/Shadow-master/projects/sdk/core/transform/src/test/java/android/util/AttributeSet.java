package android.util;

public class AttributeSet {
}
