package com.tencent.shadow.core.runtime;

public class PluginPartInfo {
    public ShadowApplication application = new ShadowApplication();
}
