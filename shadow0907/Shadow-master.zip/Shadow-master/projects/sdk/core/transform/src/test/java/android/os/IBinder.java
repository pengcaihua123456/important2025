package android.os;

public interface IBinder {
}
